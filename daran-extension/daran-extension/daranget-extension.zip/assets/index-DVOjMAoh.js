import{_ as o}from"./index-D1euVNta.js";async function i(t,r=!0){await t.addParticleUpdater("destroy",async a=>{const{DestroyUpdater:e}=await o(()=>import("./DestroyUpdater-CNpYXRql.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url);return new e(t,a)},r)}export{i as loadDestroyUpdater};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./DestroyUpdater-CNpYXRql.js","./index-D1euVNta.js","./index-CaOBZyWJ.css","./ValueWithRandom-CME2E2pC.js","./AnimationOptions-BSThJSe2.js","./OptionsColor-BwYOurOy.js","./OptionsUtils-BviBlBt4.js","./AnimatableColor-BBOsojYn.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
