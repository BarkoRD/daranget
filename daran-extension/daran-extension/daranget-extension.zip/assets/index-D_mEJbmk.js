import{_ as i}from"./index-D1euVNta.js";async function n(r,t=!0){const{AbsorbersPlugin:o}=await i(()=>import("./AbsorbersPlugin-zx19QibE.js").then(a=>a.a),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url);await r.addPlugin(new o,t)}export{n as loadAbsorbersPlugin};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./AbsorbersPlugin-zx19QibE.js","./index-D1euVNta.js","./index-CaOBZyWJ.css","./ValueWithRandom-CME2E2pC.js","./AnimationOptions-BSThJSe2.js","./OptionsColor-BwYOurOy.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
