class h{constructor(s,i,t,o){this.position=s,this.size=i,this.fill=t,this.options=o}resize(s,i){this.position=s,this.size=i}}export{h as E};
