import{_ as n}from"./index-D1euVNta.js";async function o(t,r=!0){await t.addInteractor("particlesLinks",async a=>{const{Linker:i}=await n(()=>import("./Linker-BBmMo2fM.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url);return new i(a)},r)}export{o as loadLinksInteraction};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./Linker-BBmMo2fM.js","./Ranges-BFsETcj7.js","./index-D1euVNta.js","./index-CaOBZyWJ.css","./index-CaYRr3Wb.js","./OptionsColor-BwYOurOy.js","./ParticlesInteractorBase-vfDeBun3.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
