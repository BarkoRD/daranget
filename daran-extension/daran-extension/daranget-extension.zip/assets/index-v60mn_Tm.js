import{_ as o}from"./index-D1euVNta.js";async function c(t,a=!0){var e;const r=t,{EmittersCircleShapeGenerator:i}=await o(()=>import("./EmittersCircleShapeGenerator--99CdUqh.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);(e=r.addEmitterShapeGenerator)==null||e.call(r,"circle",new i),await r.refresh(a)}export{c as loadEmittersShapeCircle};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./EmittersCircleShapeGenerator--99CdUqh.js","./EmitterShapeBase-4KcS34Iy.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
