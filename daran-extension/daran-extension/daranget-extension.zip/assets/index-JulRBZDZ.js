import{_ as r}from"./index-D1euVNta.js";async function n(t,a=!0){await t.addParticleUpdater("twinkle",async()=>{const{TwinkleUpdater:e}=await r(()=>import("./TwinkleUpdater-DvK9yXEy.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);return new e},a)}export{n as loadTwinkleUpdater};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./TwinkleUpdater-DvK9yXEy.js","./OptionsColor-BwYOurOy.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
