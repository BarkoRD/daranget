import{_ as t}from"./index-D1euVNta.js";async function o(r,a=!0){const{CircleDrawer:e}=await t(()=>import("./CircleDrawer-CR_W2dvJ.js"),__vite__mapDeps([0,1,2]),import.meta.url);await r.addShape("circle",new e,a)}export{o as loadCircleShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./CircleDrawer-CR_W2dvJ.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
