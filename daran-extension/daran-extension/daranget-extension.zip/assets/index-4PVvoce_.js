import{_ as o}from"./index-D1euVNta.js";async function i(a,e=!0){await a.addMover("base",async()=>{const{BaseMover:r}=await o(()=>import("./BaseMover-BiupUe9m.js"),__vite__mapDeps([0,1,2]),import.meta.url);return new r},e)}export{i as loadBaseMover};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./BaseMover-BiupUe9m.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
