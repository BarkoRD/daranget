import{_ as t}from"./index-D1euVNta.js";async function d(a,r=!0){const{loadBaseMover:o}=await t(()=>import("./index-4PVvoce_.js"),__vite__mapDeps([0,1,2]),import.meta.url),{loadCircleShape:_}=await t(()=>import("./index-Dyv7YZyE.js"),__vite__mapDeps([3,1,2]),import.meta.url),{loadColorUpdater:i}=await t(()=>import("./index-CzA2TUzS.js"),__vite__mapDeps([4,1,2]),import.meta.url),{loadOpacityUpdater:e}=await t(()=>import("./index-DPuCaTdK.js"),__vite__mapDeps([5,1,2]),import.meta.url),{loadOutModesUpdater:l}=await t(()=>import("./index-DeRCS6JN.js"),__vite__mapDeps([6,1,2]),import.meta.url),{loadSizeUpdater:m}=await t(()=>import("./index-B0aOMgEG.js"),__vite__mapDeps([7,1,2]),import.meta.url);await o(a,!1),await _(a,!1),await i(a,!1),await e(a,!1),await l(a,!1),await m(a,!1),await a.refresh(r)}export{d as loadBasic};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./index-4PVvoce_.js","./index-D1euVNta.js","./index-CaOBZyWJ.css","./index-Dyv7YZyE.js","./index-CzA2TUzS.js","./index-DPuCaTdK.js","./index-DeRCS6JN.js","./index-B0aOMgEG.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
