import{_ as i}from"./index-D1euVNta.js";async function m(a,t=!0){var e;const r=a,{EmittersSquareShapeGenerator:o}=await i(()=>import("./EmittersSquareShapeGenerator-m_T9Gytj.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);(e=r.addEmitterShapeGenerator)==null||e.call(r,"square",new o),await r.refresh(t)}export{m as loadEmittersShapeSquare};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./EmittersSquareShapeGenerator-m_T9Gytj.js","./EmitterShapeBase-4KcS34Iy.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
