import{_ as t}from"./index-D1euVNta.js";async function i(a,e=!0){const{SquareDrawer:r}=await t(()=>import("./SquareDrawer-C3wQIQqh.js"),__vite__mapDeps([]),import.meta.url);await a.addShape(["edge","square"],new r,e)}export{i as loadSquareShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = []
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
