class r{constructor(t){this.type="particles",this.container=t}}export{r as P};
