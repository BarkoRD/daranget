import{_ as e}from"./index-D1euVNta.js";async function i(a,t=!0){const{StarDrawer:r}=await e(()=>import("./StarDrawer-ClvqpWK3.js"),__vite__mapDeps([0,1,2]),import.meta.url);await a.addShape("star",new r,t)}export{i as loadStarShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./StarDrawer-ClvqpWK3.js","./index-D1euVNta.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
