class r{constructor(t){this.type="external",this.container=t}}export{r as E};
