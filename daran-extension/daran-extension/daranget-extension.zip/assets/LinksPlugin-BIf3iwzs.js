import{_ as i}from"./index-D1euVNta.js";class o{constructor(){this.id="links"}async getPlugin(t){const{LinkInstance:n}=await i(()=>import("./LinkInstance-dVw9_FYZ.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);return new n(t)}loadOptions(){}needsPlugin(){return!0}}export{o as LinksPlugin};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./LinkInstance-dVw9_FYZ.js","./index-D1euVNta.js","./index-CaOBZyWJ.css","./CanvasUtils-DRgNgsG8.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
