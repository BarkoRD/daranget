import{_ as e}from"./index-BqM6DdVM.js";async function i(a,t=!0){const{StarDrawer:r}=await e(()=>import("./StarDrawer-eecCb2vM.js"),__vite__mapDeps([0,1,2]),import.meta.url);await a.addShape("star",new r,t)}export{i as loadStarShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./StarDrawer-eecCb2vM.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
