import{_ as t}from"./index-BqM6DdVM.js";async function d(a,r=!0){const{loadBaseMover:o}=await t(()=>import("./index-BhUK8DE3.js"),__vite__mapDeps([0,1,2]),import.meta.url),{loadCircleShape:_}=await t(()=>import("./index-B5MEXWck.js"),__vite__mapDeps([3,1,2]),import.meta.url),{loadColorUpdater:i}=await t(()=>import("./index-BfiHOVqN.js"),__vite__mapDeps([4,1,2]),import.meta.url),{loadOpacityUpdater:e}=await t(()=>import("./index-C9MSlUL2.js"),__vite__mapDeps([5,1,2]),import.meta.url),{loadOutModesUpdater:l}=await t(()=>import("./index-pHrGwiji.js"),__vite__mapDeps([6,1,2]),import.meta.url),{loadSizeUpdater:m}=await t(()=>import("./index-BgDzDrvl.js"),__vite__mapDeps([7,1,2]),import.meta.url);await o(a,!1),await _(a,!1),await i(a,!1),await e(a,!1),await l(a,!1),await m(a,!1),await a.refresh(r)}export{d as loadBasic};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./index-BhUK8DE3.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./index-B5MEXWck.js","./index-BfiHOVqN.js","./index-C9MSlUL2.js","./index-pHrGwiji.js","./index-BgDzDrvl.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
