import{_ as o}from"./index-BqM6DdVM.js";async function i(t,r=!0){await t.addParticleUpdater("destroy",async a=>{const{DestroyUpdater:e}=await o(()=>import("./DestroyUpdater-DqTgV0iy.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url);return new e(t,a)},r)}export{i as loadDestroyUpdater};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./DestroyUpdater-DqTgV0iy.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./ValueWithRandom-4arkMkfX.js","./AnimationOptions-CoSRs1ZY.js","./OptionsColor-GPdQ4jnu.js","./OptionsUtils-BS0ISACv.js","./AnimatableColor-D8DNFj4O.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
