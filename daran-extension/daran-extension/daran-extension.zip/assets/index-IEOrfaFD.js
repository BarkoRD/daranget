import{_ as i}from"./index-BqM6DdVM.js";async function n(r,t=!0){const{AbsorbersPlugin:o}=await i(()=>import("./AbsorbersPlugin-FWzmo5v7.js").then(a=>a.a),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url);await r.addPlugin(new o,t)}export{n as loadAbsorbersPlugin};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./AbsorbersPlugin-FWzmo5v7.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./ValueWithRandom-4arkMkfX.js","./AnimationOptions-CoSRs1ZY.js","./OptionsColor-GPdQ4jnu.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
