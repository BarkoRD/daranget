import{_ as t}from"./index-BqM6DdVM.js";async function l(a,r=!0){await a.addMover("parallax",async()=>{const{ParallaxMover:o}=await t(()=>import("./ParallaxMover-C_oOyubB.js"),__vite__mapDeps([0,1,2]),import.meta.url);return new o},r)}export{l as loadParallaxMover};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./ParallaxMover-C_oOyubB.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
