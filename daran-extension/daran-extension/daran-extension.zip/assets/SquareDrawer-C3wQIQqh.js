const i=Math.sqrt(2),o=2;function s(t){const{context:r,radius:d}=t,e=d/i,a=e*o;r.rect(-e,-e,a,a)}const c=4;class u{draw(r){s(r)}getSidesCount(){return c}}export{u as SquareDrawer};
