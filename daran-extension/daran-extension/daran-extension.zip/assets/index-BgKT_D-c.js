import{_ as o}from"./index-BqM6DdVM.js";async function c(t,a=!0){var e;const r=t,{EmittersCircleShapeGenerator:i}=await o(()=>import("./EmittersCircleShapeGenerator-BWj6rMT9.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);(e=r.addEmitterShapeGenerator)==null||e.call(r,"circle",new i),await r.refresh(a)}export{c as loadEmittersShapeCircle};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./EmittersCircleShapeGenerator-BWj6rMT9.js","./EmitterShapeBase-4KcS34Iy.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
