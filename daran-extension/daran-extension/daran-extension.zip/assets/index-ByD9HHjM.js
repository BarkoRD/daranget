import{_ as i}from"./index-BqM6DdVM.js";async function o(a,e=!0){const{LineDrawer:t}=await i(()=>import("./LineDrawer-1OQKWYNc.js"),__vite__mapDeps([]),import.meta.url);await a.addShape("line",new t,e)}export{o as loadLineShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = []
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
