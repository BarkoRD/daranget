import{_ as i}from"./index-BqM6DdVM.js";async function d(t,a=!0){await t.addParticleUpdater("tilt",async r=>{const{TiltUpdater:e}=await i(()=>import("./TiltUpdater-Dpi_xd2H.js"),__vite__mapDeps([0,1,2,3,4]),import.meta.url);return new e(r)},a)}export{d as loadTiltUpdater};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./TiltUpdater-Dpi_xd2H.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./ValueWithRandom-4arkMkfX.js","./AnimationOptions-CoSRs1ZY.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
