import{_ as t}from"./index-BqM6DdVM.js";async function o(r,a=!0){const{CircleDrawer:e}=await t(()=>import("./CircleDrawer-U0416WVv.js"),__vite__mapDeps([0,1,2]),import.meta.url);await r.addShape("circle",new e,a)}export{o as loadCircleShape};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./CircleDrawer-U0416WVv.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
