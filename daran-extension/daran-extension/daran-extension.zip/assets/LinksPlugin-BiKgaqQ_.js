import{_ as i}from"./index-BqM6DdVM.js";class o{constructor(){this.id="links"}async getPlugin(t){const{LinkInstance:n}=await i(()=>import("./LinkInstance-CKJJXeQi.js"),__vite__mapDeps([0,1,2,3]),import.meta.url);return new n(t)}loadOptions(){}needsPlugin(){return!0}}export{o as LinksPlugin};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./LinkInstance-CKJJXeQi.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./CanvasUtils-B2-ydBlP.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
