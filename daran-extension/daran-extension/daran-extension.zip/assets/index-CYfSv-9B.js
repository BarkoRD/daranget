import{_ as o}from"./index-BqM6DdVM.js";async function d(t,a=!0){await t.addParticleUpdater("rotate",async r=>{const{RotateUpdater:e}=await o(()=>import("./RotateUpdater-BkyF9Orv.js"),__vite__mapDeps([0,1,2,3,4]),import.meta.url);return new e(r)},a)}export{d as loadRotateUpdater};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./RotateUpdater-BkyF9Orv.js","./index-BqM6DdVM.js","./index-CaOBZyWJ.css","./ValueWithRandom-4arkMkfX.js","./AnimationOptions-CoSRs1ZY.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
